--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 15.4 (Debian 15.4-3)
-- Dumped by pg_dump version 15.4 (Debian 15.4-3)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE xp_bot;
--
-- Name: xp_bot; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE xp_bot WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'C.UTF-8';


ALTER DATABASE xp_bot OWNER TO postgres;

\connect xp_bot

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: quiz; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA quiz;


ALTER SCHEMA quiz OWNER TO postgres;

--
-- Name: users; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA users;


ALTER SCHEMA users OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: quiz; Type: TABLE; Schema: quiz; Owner: postgres
--

CREATE TABLE quiz.quiz (
    id bigint NOT NULL,
    question text,
    answer text,
    point bigint,
    id_chat bigint,
    id_creating bigint,
    idfile_foto_correct text
);


ALTER TABLE quiz.quiz OWNER TO postgres;

--
-- Name: users; Type: TABLE; Schema: users; Owner: postgres
--

CREATE TABLE users.users (
    guid bigint NOT NULL,
    gid bigint,
    uid bigint,
    xp integer,
    next_xp bigint
);


ALTER TABLE users.users OWNER TO postgres;

--
-- Data for Name: quiz; Type: TABLE DATA; Schema: quiz; Owner: postgres
--

COPY quiz.quiz (id, question, answer, point, id_chat, id_creating, idfile_foto_correct) FROM stdin;
\.
COPY quiz.quiz (id, question, answer, point, id_chat, id_creating, idfile_foto_correct) FROM '$$PATH$$/3996.dat';

--
-- Data for Name: users; Type: TABLE DATA; Schema: users; Owner: postgres
--

COPY users.users (guid, gid, uid, xp, next_xp) FROM stdin;
\.
COPY users.users (guid, gid, uid, xp, next_xp) FROM '$$PATH$$/3997.dat';

--
-- Name: quiz quiz_pkey; Type: CONSTRAINT; Schema: quiz; Owner: postgres
--

ALTER TABLE ONLY quiz.quiz
    ADD CONSTRAINT quiz_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: users; Owner: postgres
--

ALTER TABLE ONLY users.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (guid);


--
-- PostgreSQL database dump complete
--

